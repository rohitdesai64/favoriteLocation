let userData = require("../data.json");

const allUsers = (state = [], action) => {
        return userData
    }

export default allUsers
export default {
    grow: {
        flexGrow: 1
    },
    fullWidth: {
        width: '100%'
    },
    padd15: {
        padding: 15
    }
}
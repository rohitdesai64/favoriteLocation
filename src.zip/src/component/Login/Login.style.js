export default {
    mainBody: {
        height: '100vh',
        backgroundColor: '#f0f0f0'
    },
    pad20: {
        padding: 20
    },
    loginBox: {
        padding: 30,
        backgroundColor: '#fff',
        width: 300
    },
    formInput: {
        width: '100%'
    }
}
export default {
  drawer: {
    width: 300 ,
    // minWidth: 300
  }
}